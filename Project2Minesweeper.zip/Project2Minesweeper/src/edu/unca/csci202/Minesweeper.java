package edu.unca.csci202;

import java.util.Scanner;

public class Minesweeper {
	public static final String WHITE_BOLD = "\033[1;37m"; // WHITE

	public static void main(String[] args) {
		while (true) {
			Scanner scanner = new Scanner(System.in);
			Gameboard gameboard = new Gameboard();
			intro(); // thanks patorjk.com
			gameboard.run();
			boolean keepPlaying = getUserContinue(scanner, "Would you like to play again? (y/n): ");
			if (!keepPlaying)
				break;
			else
				continue;
		}
	}

	private static void intro() {
		System.out.println(" ___  ____                                                   \n"
				+ " |  \\/  (_)                      " + WHITE_BOLD + "welcome to..." + Gameboard.RESET
				+ "                     \n" + " | .  . |_ _ __   ___  _____      _____  ___ _ __   ___ _ __ \n"
				+ " | |\\/| | | '_ \\ / _ \\/ __\\ \\ /\\ / / _ \\/ _ \\ '_ \\ / _ \\ '__|\n"
				+ " | |  | | | | | |  __/\\__ \\\\ V  V /  __/  __/ |_) |  __/ |   \n"
				+ " \\_|  |_/_|_| |_|\\___||___/ \\_/\\_/ \\___|\\___| .__/ \\___|_|   \n"
				+ "                                            | |              \n"
				+ "                                            |_|              ");
	}

	private static boolean getUserContinue(Scanner scanner, String msg) {
		while (true) {
			System.out.print(msg);
			char input = scanner.next().charAt(0);
			if (input == 'y' || input == 'Y') {
				scanner.nextLine();
				return true;
			} else if (input == 'n' || input == 'N') {
				scanner.nextLine();
				return false;
			} else
				System.out.println("Try again; must be either y or n.");
			continue;
		}
	}
}
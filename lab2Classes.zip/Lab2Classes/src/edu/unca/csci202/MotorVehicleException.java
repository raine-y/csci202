package edu.unca.csci202;

public class MotorVehicleException extends Exception {
	private static final long serialVersionUID = 1L;
	public MotorVehicleException(String message) {
		super(message);
	}
}
